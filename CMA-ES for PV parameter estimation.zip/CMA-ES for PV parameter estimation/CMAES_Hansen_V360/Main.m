clear all
clc

format long;
format compact;
warning('off');

runtime = 50;
opts.MaxFunEvals = 10000;
insigma = 0.1;
allsolution = [];
finalresults = [];
result_runtime = [];

tic()
    indexFun = input('Input the type of PV Case:');

 % Problem Settings
 if indexFun == 1
     %PV_Single_Cell
     bounds=[0,1;0,1e-6;0,0.5;0,100;1,2;]';
     opts.LBounds = bounds(1,:)';
     opts.UBounds = bounds(2,:)';
     nVar = 5;               % Number of Unknown (Decision) Variables
     for j=1:runtime
         xstart = opts.LBounds + rand(nVar,1) .* (opts.UBounds - opts.LBounds);
         [xmin, fmin,counteval, stopflag, out, bestever, result_iteration] = cmaes_V360('PV_1',  xstart, insigma, opts);
         xx = round(linspace(1,length(result_iteration),100));
         result_runtime = [result_runtime result_iteration(xx)];
         finalresults = [finalresults; fmin];
         allsolution = [allsolution xmin];
     end
     
 elseif indexFun==2
     %PV_Double_Cell
     bounds=[0,1;0,1e-6;0,0.5;0,100;1,2;0,1e-6;1,2;]';
     opts.LBounds = bounds(1,:)';
     opts.UBounds = bounds(2,:)';
     nVar = 7;               % Number of Unknown (Decision) Variables
     for j=1:runtime
         xstart = opts.LBounds + rand(nVar,1) .* (opts.UBounds - opts.LBounds);
         [xmin, fmin,counteval, stopflag, out, bestever, result_iteration] = cmaes_V360('PV_2',  xstart, insigma, opts);
         xx = round(linspace(1,length(result_iteration),100));
         result_runtime = [result_runtime result_iteration(xx)];
         finalresults = [finalresults; fmin];
         allsolution = [allsolution xmin];
     end

 elseif indexFun==3
     %PV_Photowatt_PWP201_Module
     bounds=[0,10;0,50e-6;0,2;0,2000;1,50;]';
     opts.LBounds = bounds(1,:)';
     opts.UBounds = bounds(2,:)';
     nVar = 5;               % Number of Unknown (Decision) Variables
     for j=1:runtime
         xstart = opts.LBounds + rand(nVar,1) .* (opts.UBounds - opts.LBounds);
         [xmin, fmin,counteval, stopflag, out, bestever, result_iteration] = cmaes_V360('PV_3',  xstart, insigma, opts);
         xx = round(linspace(1,length(result_iteration),100));
         result_runtime = [result_runtime result_iteration(xx)];
         finalresults = [finalresults; fmin];
         allsolution = [allsolution xmin];
     end
    
 elseif indexFun==4
     %PV_STM6_40_36_Module
     bounds=[0,2;0,50e-6;0,0.36;0,1000;1,60;]';
     opts.LBounds = bounds(1,:)';
     opts.UBounds = bounds(2,:)';
     nVar = 5;               % Number of Unknown (Decision) Variables
     for j=1:runtime
         xstart = opts.LBounds + rand(nVar,1) .* (opts.UBounds - opts.LBounds);
         [xmin, fmin,counteval, stopflag, out, bestever, result_iteration] = cmaes_V360('PV_4',  xstart, insigma, opts);
         xx = round(linspace(1,length(result_iteration),100));
         result_runtime = [result_runtime result_iteration(xx)];
         finalresults = [finalresults; fmin];
         allsolution = [allsolution xmin];
     end

 elseif indexFun==5
     %PV_STP6_120_36_Module
     bounds=[0,8;0,50e-6;0,0.36;0,1500;1,50;]';
     opts.LBounds = bounds(1,:)';
     opts.UBounds = bounds(2,:)';
     nVar = 5;               % Number of Unknown (Decision) Variables
     for j=1:runtime
         xstart = opts.LBounds + rand(nVar,1) .* (opts.UBounds - opts.LBounds);
         [xmin, fmin,counteval, stopflag, out, bestever, result_iteration] = cmaes_V360('PV_5',  xstart, insigma, opts);
         xx = round(linspace(1,length(result_iteration),100));
         result_runtime = [result_runtime result_iteration(xx)];
         finalresults = [finalresults; fmin];
         allsolution = [allsolution xmin];
     end
 end

rmse_static=[min(finalresults),max(finalresults),mean(finalresults),std(finalresults)];

disp(strcat('Min=',num2str(rmse_static(1)),',Max=',num2str(rmse_static(3)),',Mean=',num2str(rmse_static(2)),',Std=',num2str(rmse_static(4))));

str2='Allresults_CMAESHansen';
str3=strcat(str2, num2str(indexFun), '.xls');
xlswrite( str3, rmse_static') ;

str2='results_CMAESHansen';
str3=strcat(str2, num2str(indexFun), '.xls');
xlswrite( str3, result_runtime) ;

str2='solution_CMAESHansen';
str3=strcat(str2, num2str(indexFun),'.xls');
xlswrite( str3, allsolution) ;

toc()

