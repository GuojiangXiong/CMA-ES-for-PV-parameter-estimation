function z = PV_Single_Cell(x)

%     z = 20*(1-exp(-0.2*sqrt(mean(x.^2))))+exp(1)-exp(mean(cos(2*pi*x)));


Data =[-0.2057 	0.7640
    -0.1291 	0.7620
    -0.0588 	0.7605
    0.0057 	0.7605
    0.0646 	0.7600
    0.1185 	0.7590
    0.1678 	0.7570
    0.2132 	0.7570
    0.2545 	0.7555
    0.2924 	0.7540
    0.3269 	0.7505
    0.3585 	0.7465
    0.3873 	0.7385
    0.4137 	0.7280
    0.4373 	0.7065
    0.4590 	0.6755
    0.4784 	0.6320
    0.4960 	0.5730
    0.5119 	0.4990
    0.5265 	0.4130
    0.5398 	0.3165
    0.5521 	0.2120
    0.5633 	0.1035
    0.5736 	-0.0100
    0.5833 	-0.1230
    0.5900 	-0.2100 ];


[numData,~] = size(Data);

I_L = Data(:,2)';
V_L = Data(:,1)';

V = Data(:,1);
I = Data(:,2);

q = 1.60217646e-19;
k = 1.3806503e-23;
T = 273.15 + 33;		% the temperature is set as 33 centi-degree
V_t = k * T / q;
VT = V_t;
Ns = 1;

% Compute the cost of each member in Population
    gene = x;
    %/* extracted parameters */
	I_ph = gene(1,1);
	I_SD = gene(1,2);
	R_s	 = gene(1,3);
    R_sh = gene(1,4);
    n	 = gene(1,5);
    
    result1 = I_ph - I_SD * ( exp( (V_L + I_L*R_s) / (V_t*n) ) - 1.0 ) - ( (V_L + I_L*R_s)/R_sh ) - I_L;
    result2 = sum(result1.^2,2);
    Cost = sqrt(result2/numData);
    
    z = Cost;

end


