function z = PV_STP6_120_36_Module(x)


Data =[19.21	0
17.65	3.83
17.41	4.29
17.25	4.56
17.1	4.79
16.9	5.07
16.76	5.27
16.34	5.75
16.08	6
15.71	6.36
15.39	6.58
14.93	6.83
14.58	6.97
14.17	7.1
13.59	7.23
13.16	7.29
12.74	7.34
12.36	7.37
11.81	7.38
11.17	7.41
10.32	7.44
9.74	7.42
9.06	7.45
0	7.48];


[numData,~] = size(Data);

I_L = Data(:,2)';
V_L = Data(:,1)';

q = 1.60217646e-19;
k = 1.3806503e-23;
T = 273.15 + 55;		% the temperature is set as 51 centi-degree
V_t = k * T / q;
Ns = 36;

% Compute the cost of each member in Population
Cost = zeros(1,1);

    gene = x;
    %/* extracted parameters */
	I_ph = gene(1,1);
	I_SD = gene(1,2);
	R_s	 = gene(1,3);
	R_sh = gene(1,4);
	n	 = gene(1,5);

%     result1 = I_ph - I_SD * ( exp( (q*(V_L/Ns + I_L*R_s)) / (n*k*T) ) -1.0 ) - ( (V_L/Ns + I_L*R_s)/R_sh ) - I_L;
    result1 = I_ph - I_SD * (exp((V_L + Ns * I_L * R_s)/( n*Ns*V_t)) - 1.0 ) - ( V_L + Ns * I_L*R_s)/(Ns*R_sh) - I_L;

    result2 = sum(result1.^2,2);
    Cost = sqrt(result2/numData);
    z = Cost;

end


