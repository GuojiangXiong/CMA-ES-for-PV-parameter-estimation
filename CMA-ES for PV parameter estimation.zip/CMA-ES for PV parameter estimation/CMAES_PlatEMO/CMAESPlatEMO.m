% clc
% clear all
function CMAESPlatEMO
% population size setting
% m = 50;     
global m runnum Case Max_FEs

[Max_gen, MaxParValue, MinParValue, d] = Problem(Case,m);
% Max_gen = 500;
finalresults = [];
% Max_FEs = 50000;
% results = zeros(runnum,Max_gen);
solution = [];

% several runs
for run = 1 : runnum
    run
    
    % Initialization
    % Number of parents
    lambda = m;
    mu = lambda/2;
    % Parent weights
    w = log(mu+0.5) - log(1:mu);
    w = w./sum(w);
    % Number of effective solutions
    mu_eff = 1/sum(w.^2);
    % Step size control parameters
    cs = (mu_eff+2)/(d+mu_eff+5);
    ds  = 1 + cs + 2*max(sqrt((mu_eff-1)/(d+1))-1,0);
    ENN    = sqrt(d)*(1-1/(4*d)+1/(21*d^2));
    % Covariance update parameters
    cc     = (4+mu_eff/d)/(4+d+2*mu_eff/d);
    c1     = 2/((d+1.3)^2+mu_eff);
    cmu    = min(1-c1,2*(mu_eff-2+1/mu_eff)/((d+2)^2+2*mu_eff/2));
    hth    = (1.4+2/(d+1))*ENN;
    % Initialization
    Mdec  = unifrnd(MinParValue,MaxParValue);
    ps    = zeros(1,d);
    pc    = zeros(1,d);
    C     = eye(d);
    sigma = 0.1;
    Population = repmat(MinParValue,m,1) + rand(m,d) .* repmat((MaxParValue - MinParValue),m,1);
    [Objective_values, Population] = fitness(Population,Case);
    FEs = 0;
    pbestval = Objective_values; %initialize the pbest and the pbest's fitness value
    [gbestval,gbestid] = min(pbestval);
    best = Population(gbestid,:);
    MinimumCost = gbestval;
    bestsolution = best;
%     gbest = pbest(gbestid,:);      %initialize the gbest and the gbest's fitness value
    %=========================================================================%
    %%%                         BBO Main Loop                               %%%
    %     FES = m;
    gen = 0;
    results = [];
    tic;
    % main loop
%     while(gen < Max_gen)
    while(FEs < Max_FEs)  
        
        % Sample solutions
        for i = 1 : lambda
            Pstep(i,:) = mvnrnd(zeros(1,d),C);
        end
        Pdec       = Mdec + sigma.*Pstep;
        [Objective_values, Pdec] = fitness(Pdec,Case);        
        FEs = FEs + lambda;
        Population = Pdec;
        % Update mean
        [~,rank] = sort(Objective_values);
        Objective_values = Objective_values(rank);
        Population = Population(rank,:);
        Pstep    = Pstep(rank,:);
        Mstep    = w*Pstep(1:mu,:);
        Mdec     = Mdec + sigma.*Mstep;
        % Update parameters
        ps    = (1-cs)*ps + sqrt(cs*(2-cs)*mu_eff)*Mstep/chol(C)';
        sigma = sigma*exp(cs/ds*(norm(ps)/ENN-1))^0.3;
        hs    = norm(ps)/sqrt(1-(1-cs)^(2*(ceil(FEs/lambda)+1))) < hth;
        delta = (1-hs)*cc*(2-cc);
        pc    = (1-cc)*pc + hs*sqrt(cc*(2-cc)*mu_eff)*Mstep;
        C     = (1-c1-cmu)*C + c1*(pc'*pc+delta*C);
        for i = 1 : mu
            C = C + cmu*w(i)*Pstep(i,:)'*Pstep(i,:);
        end
        [V,E] = eig(C);
        if any(diag(E)<0)
            C = V*max(E,0)/V;
        end
        
        if Objective_values(1) < gbestval
            gbestval = Objective_values(1);
            best = Population(1,:);
            MinimumCost = gbestval;
            bestsolution = best;
        end

        % Display Iteration Information
        gen = gen + 1;
%         results(run,gen) = MinimumCost;
        results = [results; MinimumCost];
%         fprintf('Best fitness: %e gen %d\n', MinimumCost,gen);
%         fprintf('Best fitness: %e and avg:  %e gen %d\n', MinimumCost, mean(Objective_values), gen);
        
    end
    xx = round(linspace(1,length(results),100));
    finalresults = [finalresults results(xx)];
    solution = [solution; bestsolution];
    fprintf('Run No.%d Done!\n', run);
    disp(['CPU time: ',num2str(toc)]);
end

Maxresult = max(finalresults(end,1:runnum));
Meanresult = mean(finalresults(end,1:runnum));
Minresult = min(finalresults(end,1:runnum));
stdresult = std(finalresults(end,1:runnum));
Allresults = [Minresult; Maxresult; Meanresult; stdresult];

Allresults_CMAES = Allresults;
results_CMAES = finalresults;
solution_CMAES = solution';

str2='Allresults_CMAESPlatEMO';
str3=strcat(str2, num2str(Case), '.xls');
xlswrite( str3, Allresults_CMAES') ;

str2='results_CMAESPlatEMO';
str3=strcat(str2, num2str(Case), '.xls');
xlswrite( str3, results_CMAES) ;


str2='solution_CMAESPlatEMO';
str3=strcat(str2, num2str(Case),'.xls');
xlswrite( str3, solution_CMAES) ;

return
