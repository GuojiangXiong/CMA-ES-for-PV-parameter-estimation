clc
clear all

format long;
format compact;
warning('off');

global m runnum Case Max_FEs

runnum = 30;   % the number of trial runs
m = 20;        % population size
Max_FEs = 10000;   % the maximum number of function evaluations

% 1��RTC France silicon solar cell, SDM
% 2��RTC France silicon solar cell, DDM
% 3��Photowatt-PWP201 module
% 4��STM6-40/36 module
% 5��STP6-120/36 module

for Case = [1 2 3 4 5]

CMAESPlatEMO

end