function [Cost, NewX] = PV_Photowatt_PWP201_Module(pop)

[popsize,numVar] = size(pop);

bounds=[0,10;0,50e-6;0,2;0,2000;1,50;]';
MinParValue = bounds(1,:);
MaxParValue = bounds(2,:);

for i = 1 : popsize    
    for k = 1 : numVar
        if (pop(i,k) < MinParValue(1,k)) | (pop(i,k) > MaxParValue(1,k))
            pop(i,k) = MinParValue(1,k) + rand * (MaxParValue(1,k) - MinParValue(1,k));
        end
    end    
end

NewX = pop;

Data =[0.1248 	1.0315
    1.8093 	1.0300
    3.3511 	1.0260
    4.7622 	1.0220
    6.0538 	1.0180
    7.2364 	1.0155
    8.3189 	1.0140
    9.3097 	1.0100
    10.2163 	1.0035
    11.0449 	0.9880
    11.8018 	0.9630
    12.4929 	0.9255
    13.1231 	0.8725
    13.6983 	0.8075
    14.2221 	0.7265
    14.6995 	0.6345
    15.1346 	0.5345
    15.5311 	0.4275
    15.8929 	0.3185
    16.2229 	0.2085
    16.5241 	0.1010
    16.7987 	-0.0080
    17.0499 	-0.1110
    17.2793 	-0.2090
    17.4885 	-0.3030 ];


[numData,~] = size(Data);

I_L = Data(:,2)';
V_L = Data(:,1)';

q = 1.60217646e-19;
k = 1.3806503e-23;
T = 273.15 + 45;		% the temperature is set as 45 centi-degree
% V_t = k * T / q;
Ns = 1;

% Compute the cost of each member in Population
Cost = zeros(1,popsize);
for popindex = 1 : popsize
    gene = NewX(popindex,:);
    %/* extracted parameters */
	I_ph = gene(1,1);
	I_SD = gene(1,2);
	R_s	 = gene(1,3);
	R_sh = gene(1,4);
	n	 = gene(1,5);

    result1 = I_ph - I_SD * ( exp( (q*(V_L/Ns + I_L*R_s)) / (n*k*T) ) -1.0 ) - ( (V_L/Ns + I_L*R_s)/R_sh ) - I_L;

    result2 = sum(result1.^2,2);
    Cost(popindex) = sqrt(result2/numData);

end


