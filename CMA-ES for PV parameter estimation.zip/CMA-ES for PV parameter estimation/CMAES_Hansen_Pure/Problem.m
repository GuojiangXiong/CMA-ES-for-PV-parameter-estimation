function [Max_gen, MaxParValue, MinParValue, d] = Problem(Case,m)
global Max_FEs
if Case == 1
    % % %---------------Case1��SDM------------------------------------
    bounds=[0,1;0,1e-6;0,0.5;0,100;1,2;]';
    MinParValue = bounds(1,:);
    MaxParValue = bounds(2,:);
    d = 5;
    Max_gen = ceil(Max_FEs / m);

elseif Case == 2
    
    % % %---------------Case2��DDM------------------------------------
    bounds=[0,1;0,1e-6;0,0.5;0,100;1,2;0,1e-6;1,2;]';
    MinParValue = bounds(1,:);
    MaxParValue = bounds(2,:);
    d = 7;
    Max_gen = ceil(Max_FEs / m);
    
elseif Case == 3

    % % %---------------Case3��Photowatt-PWP201 module------------------------------------
    bounds=[0,10;0,50e-6;0,2;0,2000;1,50;]';
    MinParValue = bounds(1,:);
    MaxParValue = bounds(2,:);
    d = 5;
    Max_gen = ceil(Max_FEs / m);
    
elseif Case == 4
    
    % % %---------------Case4��PV_STM6_40_36_Module------------------------------------
    bounds=[0,2;0,50e-6;0,0.36;0,1000;1,60;]';
    MinParValue = bounds(1,:);
    MaxParValue = bounds(2,:);
    d = 5;
    Max_gen = ceil(Max_FEs / m);
    
elseif Case == 5
    
    % % %---------------Case5��PV_STP6_120_36_Module------------------------------------
    bounds=[0,8;0,50e-6;0,0.36;0,1500;1,50;]';
    MinParValue = bounds(1,:);
    MaxParValue = bounds(2,:);
    d = 5;
    Max_gen = ceil(Max_FEs / m);


end

