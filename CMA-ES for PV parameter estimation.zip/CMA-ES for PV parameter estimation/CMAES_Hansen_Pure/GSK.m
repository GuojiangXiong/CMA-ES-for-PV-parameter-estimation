% clc
% clear all
function GSK
% population size setting
% m = 50;     
global m runnum Case Max_FEs
%runnum: the number of trial runs
% runnum =1;
KF = 0.5;  % Knowledge Factor
KR = 0.9;  %Knowledge Ratio
K = 10;    %Knowledge Rate
p = 0.1;

% Max_FEs = d * 10000;
% Max_gen = Max_FEs / m;
FE_NM = m;
[Max_gen, MaxParValue, MinParValue, d] = Problem(Case,m);
Max_gen = round(Max_gen);
finalresults = [];
% Max_FEs = 50000;
results = zeros(runnum,Max_gen);
solution = [];

% several runs
for run = 1 : runnum
    run
    %%%                      Initialize Population                          %%%
    
    Population = repmat(MinParValue,m,1) + rand(m,d) .* repmat((MaxParValue - MinParValue),m,1);
    TempPop = zeros (m , d);           % Temporary population
    [Objective_values, Population] = fitness(Population,Case);
    bestever = 1e200;
    FEs = m;
    % Sort Population
%     [Population,Objective_values] = PopulationSort(Population,Objective_values);
%     pbest = Population;
    pbestval = Objective_values; %initialize the pbest and the pbest's fitness value
    [gbestval,gbestid] = min(pbestval);
    best = Population(gbestid,:);
%     gbest = pbest(gbestid,:);      %initialize the gbest and the gbest's fitness value
    %=========================================================================%
    %%%                         BBO Main Loop                               %%%
    %     FES = m;
    gen = 0;
    results = [];
    tic;
    % main loop
%     while(gen < Max_gen)
    while(FEs < Max_FEs)  
%         fi = cos((pi*FEs) / (2*Max_FEs));
%         KF = fi * KFmax + (1 - fi) * KFmin;
%         KR = (1 - fi) * KRmax + fi * KRmin;
        % Sort Population
        [Population,Objective_values] = PopulationSort(Population,Objective_values);
        D_Gained_Shared_Junior = ceil(d*(1 - FEs / Max_FEs)^K);
%         D_Gained_Shared_Senior = d - D_Gained_Shared_Junior;
        % Use migration rates to GSKciGSK how much information to share between solutions
        for i = 1 : m
            % Gained_Shared_Junior_R1R2R3
            if(i==1)% best
                r1_Junior = 2;
                r2_Junior = 3;
            elseif(i == m)% worst
                r1_Junior = m - 2;
                r2_Junior = m - 1;
            else
                r1_Junior = i - 1;
                r2_Junior = i + 1;
            end
            while true
                r3_Junior = round(m * rand + 0.5);
                if (r3_Junior ~= r1_Junior) && (r3_Junior ~= r2_Junior) && (r3_Junior ~= i) , break, end
            end
            
            % Gained_Shared_Senior_R1R2R3
            r1_Senior = ceil(p*m * rand);
            r2_Senior = ceil((1-p) * m) + ceil(p*m * rand);
            while true
                r3_Senior = ceil(p * m) + ceil((1-2*p)*m * rand);
                if (r3_Senior ~= i), break, end
            end

            for j = 1:d
                if (rand < KR)
                    if rand < D_Gained_Shared_Junior/d
                        if i < r3_Junior
                            TempPop(i,j) = Population(i,j) + KF * (Population(r1_Junior,j) - Population(r2_Junior,j)) + ...
                                                             KF * (Population(i,j) - Population(r3_Junior,j));
                        else
                            TempPop(i,j) = Population(i,j) + KF * (Population(r1_Junior,j) - Population(r2_Junior,j)) + ...
                                                             KF * (Population(r3_Junior,j) - Population(i,j));
                        end
                    else
                        if i < r3_Senior
                            TempPop(i,j) = Population(i,j) + KF * (Population(r1_Senior,j) - Population(r2_Senior,j)) + ...
                                                             KF * (Population(i,j) - Population(r3_Senior,j));
                        else
                            TempPop(i,j) = Population(i,j) + KF * (Population(r1_Senior,j) - Population(r2_Senior,j)) + ...
                                                             KF * (Population(r3_Senior,j) - Population(i,j));
                        end
                    end
                else
                    TempPop(i,j) = Population(i,j);
                end
            end
        end
        
        
        % Evaluation
        [Objective_values_TempPop, TempPop] = fitness(TempPop,Case);
        FEs = FEs + m;
        % Comparision
        mask = Objective_values_TempPop < Objective_values;
        aa = repmat(mask',1,d);
        Population = aa .* TempPop + ~aa .* Population;
        Objective_values = mask .* Objective_values_TempPop + ~mask .* Objective_values;
        [gbestval,gbestid] = min(Objective_values);
        best = Population(gbestid,:);
        
        
        MinimumCost = gbestval;
        bestsolution = Population(gbestid,:);
        % Display Iteration Information
        gen = gen + 1;
%         results(run,gen) = MinimumCost;
        results = [results; MinimumCost];
%         fprintf('Best fitness: %e gen %d\n', MinimumCost,gen);
%         fprintf('Best fitness: %e and avg:  %e gen %d\n', MinimumCost, mean(Objective_values), gen);
        
    end
    xx = round(linspace(1,length(results),100));
    finalresults = [finalresults results(xx)];
    solution = [solution; bestsolution];
    fprintf('Run No.%d Done!\n', run);
    disp(['CPU time: ',num2str(toc)]);
end

Maxresult = max(finalresults(end,1:runnum));
Meanresult = mean(finalresults(end,1:runnum));
Minresult = min(finalresults(end,1:runnum));
stdresult = std(finalresults(end,1:runnum));
Allresults = [Minresult; Maxresult; Meanresult; stdresult];

Allresults_GSK = Allresults;
results_GSK = [finalresults];
solution_GSK = solution';

str2='Allresults_GSK';
str3=strcat(str2, num2str(Case), '.xls');
xlswrite( str3, Allresults_GSK') ;

str2='results_GSK';
str3=strcat(str2, num2str(Case), '.xls');
xlswrite( str3, results_GSK) ;


str2='solution_GSK';
str3=strcat(str2, num2str(Case),'.xls');
xlswrite( str3, solution_GSK) ;

return
