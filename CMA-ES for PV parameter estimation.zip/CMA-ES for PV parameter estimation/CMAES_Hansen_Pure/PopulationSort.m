%%%        Sort the population and costs from best to worst             %%%
function [Population,Objective_values] = PopulationSort(Population,Objective_values)

[~ , indices] = sort([Objective_values]);
Population = Population(indices,:);
Objective_values = Objective_values(indices);
return