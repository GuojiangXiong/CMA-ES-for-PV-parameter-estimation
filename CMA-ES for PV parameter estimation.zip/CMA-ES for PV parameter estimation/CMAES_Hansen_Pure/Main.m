clc
clear all

format long;
format compact;
warning('off');

global m runnum Case Max_FEs

runnum = 30;   % the number of trial runs
m = 20;        % population size
Max_FEs = 10000;   % the maximum number of function evaluations

% 1001��RTC France silicon solar cell, SDM
% 1002��RTC France silicon solar cell, DDM
% 1003��Photowatt-PWP201 module
% 1004��STM6-40/36 module
% 1005��STP6-120/36 module

% for Case = [1 2 3 4 5]
for Case = 3
% DE
% GSK
CMAESHansen

end