function [Cost, NewX] = PV_STM6_40_36_Module(pop)

[popsize,numVar] = size(pop);

bounds=[0,2;0,50e-6;0,0.36;0,1000;1,60;]';
MinParValue = bounds(1,:);
MaxParValue = bounds(2,:);

for i = 1 : popsize    
    for k = 1 : numVar
        if pop(i,k) < MinParValue(1,k) | pop(i,k) > MaxParValue(1,k)
            pop(i,k) = MinParValue(1,k) + rand * (MaxParValue(1,k) - MinParValue(1,k));
        end
    end    
end


NewX = pop;

Data =[0	1.663
0.118	1.663
2.237	1.661
5.434	1.653
7.26	1.65
9.68	1.645
11.59	1.64
12.6	1.636
13.37	1.629
14.09	1.619
14.88	1.597
15.59	1.581
16.4	1.542
16.71	1.524
16.98	1.5
17.13	1.485
17.32	1.465
17.91	1.388
19.08	1.118
21.02	0];


[numData,~] = size(Data);

I_L = Data(:,2)';
V_L = Data(:,1)';

q = 1.60217646e-19;
k = 1.3806503e-23;
T = 273.15 + 51;		% the temperature is set as 51 centi-degree
V_t = k * T / q;
Ns = 36;

% Compute the cost of each member in Population
Cost = zeros(1,popsize);
for popindex = 1 : popsize
    gene = NewX(popindex,:);
    %/* extracted parameters */
	I_ph = gene(1,1);
	I_SD = gene(1,2);
	R_s	 = gene(1,3);
	R_sh = gene(1,4);
	n	 = gene(1,5);

%     result1 = I_ph - I_SD * ( exp( (q*(V_L/Ns + I_L*R_s)) / (n*k*T) ) -1.0 ) - ( (V_L/Ns + I_L*R_s)/R_sh ) - I_L;
    result1 = I_ph - I_SD * (exp((V_L + Ns * I_L * R_s)/( n*Ns*V_t)) - 1.0 ) - ( V_L + Ns * I_L*R_s)/(Ns*R_sh) - I_L;

    result2 = sum(result1.^2,2);
    Cost(popindex) = sqrt(result2/numData);

end


