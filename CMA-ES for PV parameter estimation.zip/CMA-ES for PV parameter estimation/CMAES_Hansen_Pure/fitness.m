function [fvalue, NEWX] = fitness(x,Prob)

if Prob == 1
    [fvalue, NEWX] = PV_Single_Cell(x);
      
elseif Prob == 2
    
    [fvalue, NEWX] = PV_Double_Cell(x);
    
elseif Prob == 3
    
    [fvalue, NEWX] = PV_Photowatt_PWP201_Module(x);

elseif Prob == 4
    
    [fvalue, NEWX] = PV_STM6_40_36_Module(x);
    
elseif Prob == 5
   
    [fvalue, NEWX] = PV_STP6_120_36_Module(x);
    
end
