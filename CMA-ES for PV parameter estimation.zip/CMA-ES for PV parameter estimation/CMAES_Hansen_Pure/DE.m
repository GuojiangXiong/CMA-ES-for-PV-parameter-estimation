% clc
% clear all
function DE
% population size setting
% m = 50;     
global m runnum Case Max_FEs
%runnum: the number of trial runs
% runnum =1;
% F = 0.6;
% CR = 0.8;

% Max_FEs = d * 10000;
% Max_gen = Max_FEs / m;

[Max_gen, MaxParValue, MinParValue, d] = Problem(Case,m);
% Max_gen = 500;
finalresults = [];
% Max_FEs = 50000;
% results = zeros(runnum,Max_gen);
solution = [];

% several runs
for run = 1 : runnum
    run
    %%%                      Initialize Population                          %%%
    
    Population = repmat(MinParValue,m,1) + rand(m,d) .* repmat((MaxParValue - MinParValue),m,1);
    TempPop = zeros (m , d);           % Temporary population
    [Objective_values, Population] = fitness(Population,Case);
    bestever = 1e200;
    FEs = m;
    % Sort Population
%     [Population,Objective_values] = PopulationSort(Population,Objective_values);
%     pbest = Population;
    pbestval = Objective_values; %initialize the pbest and the pbest's fitness value
    [gbestval,gbestid] = min(pbestval);
    best = Population(gbestid,:);
%     gbest = pbest(gbestid,:);      %initialize the gbest and the gbest's fitness value
    %=========================================================================%
    %%%                         BBO Main Loop                               %%%
    %     FES = m;
    gen = 0;
    results = [];
    tic;
    % main loop
%     while(gen < Max_gen)
    while(FEs < Max_FEs)  
        % Use migration rates to decide how much information to share between solutions
        for i = 1 : m
            % Generate the mutant "v"
            while true
                r1 = round(m * rand + 0.5);
                if (r1 ~= i), break, end
            end
            while true
                r2 = round(m * rand + 0.5);
                if (r2 ~= r1) && (r2 ~= i), break, end
            end
            while true
                r3 = round(m * rand + 0.5);
                if (r3 ~= r1) && (r3 ~= r2) && (r3 ~= i) , break, end
            end       
            F = 0.1 + 0.9 * rand;
            v = Population(r1,:) + F * (Population(r2,:) - Population(r3,:));
            
            CR = 0.9;
            j_rand = round(d * rand + 0.5);
            for j = 1 : d
                if (rand < CR || j == j_rand)
                    TempPop(i,j) = v(1,j);
                else
                    TempPop(i,j) = Population(i,j);
                end
            end
        end
        
        
        % Evaluation
        [Objective_values_TempPop, TempPop] = fitness(TempPop,Case);
        FEs = FEs + m;
        % Comparision
        mask = Objective_values_TempPop < Objective_values;
        aa = repmat(mask',1,d);
        Population = aa .* TempPop + ~aa .* Population;
        Objective_values = mask .* Objective_values_TempPop + ~mask .* Objective_values;
        [gbestval,gbestid] = min(Objective_values);
        best = Population(gbestid,:);
        MinimumCost = gbestval;
        bestsolution = Population(gbestid,:);
        % Display Iteration Information
        gen = gen + 1;
%         results(run,gen) = MinimumCost;
        results = [results; MinimumCost];
%         fprintf('Best fitness: %e gen %d\n', MinimumCost,gen);
%         fprintf('Best fitness: %e and avg:  %e gen %d\n', MinimumCost, mean(Objective_values), gen);
        
    end
    xx = round(linspace(1,length(results),100));
    finalresults = [finalresults results(xx)];
    solution = [solution; bestsolution];
    fprintf('Run No.%d Done!\n', run);
    disp(['CPU time: ',num2str(toc)]);
end

Maxresult = max(finalresults(end,1:runnum));
Meanresult = mean(finalresults(end,1:runnum));
Minresult = min(finalresults(end,1:runnum));
stdresult = std(finalresults(end,1:runnum));
Allresults = [Minresult; Maxresult; Meanresult; stdresult];

Allresults_DE = Allresults;
results_DE = finalresults;
solution_DE = solution';

str2='Allresults_DE';
str3=strcat(str2, num2str(Case),'.xls');
xlswrite( str3, Allresults_DE') ;

str2='results_DE';
str3=strcat(str2, num2str(Case),'.xls');
xlswrite( str3, results_DE) ;


str2='solution_DE';
str3=strcat(str2, num2str(Case),'.xls');
xlswrite( str3, solution_DE) ;

return
