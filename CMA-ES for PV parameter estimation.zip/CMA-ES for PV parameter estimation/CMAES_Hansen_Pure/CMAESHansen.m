% clc
% clear all
function CMAESHansen
% population size setting
% m = 40;     
global m runnum Case Max_FEs
%runnum: the number of trial runs

solution = [];
finalresults = [];
% several runs
for run = 1 : runnum
    tic;
    [Max_gen, MaxParValue, MinParValue, d] = Problem(Case,m);
    Max_gen = round(Max_gen);
    run
    %%%                      Initialize Population                          %%%
    xmean = rand(d,1);
    sigma = 0.1;          % coordinate wise standard deviation (step size)
    stopeval = Max_FEs;   % stop after stopeval number of function evaluations
    % Strategy parameter setting: Selection  
    lambda = m;
%     lambda = 4+floor(3*log(d));  % population size, offspring number
    mu = lambda/2;               % number of parents/points for recombination
    weights = log(mu+1/2)-log(1:mu)'; % muXone array for weighted recombination
    mu = floor(mu);
    weights = weights/sum(weights);     % normalize recombination weights array
    mueff=sum(weights)^2/sum(weights.^2); % variance-effectiveness of sum w_i x_i
    % Strategy parameter setting: Adaptation
    cc = (4 + mueff/d) / (d+4 + 2*mueff/d); % time constant for cumulation for C
    cs = (mueff + 2) / (d + mueff + 5);  % t-const for cumulation for sigma control
    c1 = 2 / ((d+1.3)^2 + mueff);    % learning rate for rank-one update of C
    cmu = min(1-c1, 2 * (mueff-2+1/mueff) / ((d+2)^2+mueff));  % and for rank-mu update
    damps = 1 + 2*max(0, sqrt((mueff-1)/(d+1))-1) + cs; % damping for sigma
    % usually close to 1
    % Initialize dynamic (internal) strategy parameters and constants
    pc = zeros(d,1); ps = zeros(d,1);   % evolution paths for C and sigma
    B = eye(d,d);                       % B defines the coordinate system
    SC = ones(d,1);                      % diagonal S defines the scaling
    C = B * diag(SC.^2) * B';            % covariance matrix C
    invsqrtC = B * diag(SC.^-1) * B';    % C^-1/2
    eigeneval = 0;                      % track update of B and D
    chiN = d^0.5*(1-1/(4*d)+1/(21*d^2));  % expectation of  ||N(0,I)|| == norm(randn(N,1))
    out.dat = []; out.datx = [];  % for plotting output
    counteval = 0;
    Population = repmat(MinParValue,m,1) + rand(m,d) .* repmat((MaxParValue - MinParValue),m,1);
    [Objective_values, Population] = fitness(Population,Case);
    Population = Population';
    xmean = Population(:,1:mu) * weights;  % recombination, new mean value
    
    pbestval = Objective_values; %initialize the pbest and the pbest's fitness value
    [gbestval,gbestid] = min(pbestval);
    best = Population(:,gbestid);
    gbestval = Objective_values(gbestid);
    MinimumCost = gbestval;
    bestsolution = best;
    gen = 0;    
    results = [];
    
    % main loop
    while(counteval < Max_FEs) 
        
        % Generate and evaluate lambda offspring
        for k=1:lambda
            Population(:,k) = xmean + sigma * B * (SC .* randn(d,1)); % m + sig * Normal(0,C)
            Tempop = Population(:,k)';
            [Objective_values(k), Tempop] = fitness(Tempop,Case);
            Population(:,k) = Tempop';
            counteval = counteval+1;
        end
        % Sort by fitness and compute weighted mean into xmean
        XXX = Population';
        [XXX,Objective_values] = PopulationSort(XXX,Objective_values);
        Population=XXX';
        xold = xmean;
        xmean = Population(:,1:mu) * weights;  % recombination, new mean value
        
        % Cumulation: Update evolution paths
        ps = (1-cs) * ps ...
            + sqrt(cs*(2-cs)*mueff) * invsqrtC * (xmean-xold) / sigma;
        hsig = sum(ps.^2)/(1-(1-cs)^(2*counteval/lambda))/d < 2 + 4/(d+1);
        pc = (1-cc) * pc ...
            + hsig * sqrt(cc*(2-cc)*mueff) * (xmean-xold) / sigma;
        
        % Adapt covariance matrix C
        artmp = (1/sigma) * (Population(:,1:mu) - repmat(xold,1,mu));  % mu difference vectors
        C = (1-c1-cmu) * C ...                   % regard old matrix
            + c1 * (pc * pc' ...                % plus rank one update
            + (1-hsig) * cc*(2-cc) * C) ... % minor correction if hsig==0
            + cmu * artmp * diag(weights) * artmp'; % plus rank mu update
        
        % Adapt step size sigma
        sigma = sigma * exp((cs/damps)*(norm(ps)/chiN - 1));
        
        % Update B and D from C
        if counteval - eigeneval > lambda/(c1+cmu)/d/10  % to achieve O(N^2)
            eigeneval = counteval;
            C = triu(C) + triu(C,1)'; % enforce symmetry
            [B,SC] = eig(C);           % eigen decomposition, B==normalized eigenvectors
            SC = sqrt(diag(SC));        % D contains standard deviations now
            invsqrtC = B * diag(SC.^-1) * B';
        end
        
%         [gbestval,gbestid] = min(Objective_values);
        if Objective_values(1) < gbestval
            gbestval = Objective_values(1);
            best = Population(:,1)';
            MinimumCost = gbestval;
            bestsolution = best;
        end

%         % Display Iteration Information
        gen = gen + 1;
        results = [results; MinimumCost];
%         
% %         fprintf('Best fitness: %e gen %d\n', MinimumCost,gen);
%         fprintf('Best fitness: %e and avg:  %e gen %d\n', MinimumCost, mean(Objective_values), gen);
        
    end

    xx = round(linspace(1,length(results),100));
    finalresults = [finalresults results(xx)];
    solution = [solution; bestsolution];
    fprintf('Run No.%d Done!\n', run);
    disp(['CPU time: ',num2str(toc)]);
end

Maxresult = max(finalresults(end,1:runnum));
Meanresult = mean(finalresults(end,1:runnum));
Minresult = min(finalresults(end,1:runnum));
stdresult = std(finalresults(end,1:runnum));
Allresults = [Minresult; Maxresult; Meanresult; stdresult];

Allresults_CMAES = Allresults;
results_CMAES = finalresults;
solution_CMAES = solution';

str2='Allresults_CMAESHansen';
str3=strcat(str2, num2str(Case), '.xls');
xlswrite( str3, Allresults_CMAES') ;

str2='results_CMAESHansen';
str3=strcat(str2, num2str(Case), '.xls');
xlswrite( str3, results_CMAES) ;


str2='solution_CMAESHansen';
str3=strcat(str2, num2str(Case),'.xls');
xlswrite( str3, solution_CMAES) ;

return
